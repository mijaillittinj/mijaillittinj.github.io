#!/usr/bin/env python
"""Convierte una calibración de ANNAbel (.npz) al .json que lee la herramienta del workshop (etapa 1c).

La aplicación ANNAbel del grupo guarda su calibración con la esfera integradora como un .npz con
K (3,), lam (Nl,) en nm, psi (3, Nl), T_grid (NT,), G_tab (3, NT) y meta_json. Este programa escribe un
.json con esos mismos datos y con la unidad de K dicha en el archivo.

ANNAbel trabaja en DN de 16 bits con los 12 bits desplazados (× 16) y la herramienta en DN de 12 bits.
El .json lleva "unit": "DN16" y K tal como sale de la app. La herramienta divide K por 16 al cargarlo y
lo dice. GB3 comprobó que K de la herramienta sobre K de la app es 1/16 en R, G y B.

Uso   python convertir_calibracion_annabel.py calibration.npz [salida.json]
Solo necesita numpy.
"""
from __future__ import annotations

import json
import sys
from pathlib import Path

import numpy as np

CH = ("R", "G", "B")


def _num(x):
    x = float(x)
    return x if np.isfinite(x) else None


def convert(src: Path) -> dict:
    d = np.load(src, allow_pickle=False)
    meta = {}
    if "meta_json" in d.files:
        try:
            meta = json.loads(str(d["meta_json"]))
        except ValueError:
            meta = {}
    if meta and meta.get("kind") not in (None, "annabel_app.calibration"):
        raise SystemExit(f"{src} no es una calibración de ANNAbel")
    K = np.asarray(d["K"], float).ravel()
    lam = np.asarray(d["lam"], float).ravel()
    psi = np.asarray(d["psi"], float)
    Tg = np.asarray(d["T_grid"], float).ravel()
    G = np.asarray(d["G_tab"], float)
    if K.size != 3 or psi.shape != (3, lam.size) or G.shape != (3, Tg.size):
        raise SystemExit(f"{src} no tiene la forma esperada (K de 3, psi de 3 × {lam.size}, G_tab de 3 × {Tg.size})")
    prov = meta.get("provenance", {}) if isinstance(meta, dict) else {}
    out = {
        "format": "annabel_app.calibration.json",
        "format_version": int(meta.get("format_version", 1)) if meta else 1,
        "source": src.name,
        "unit": "DN16",
        "K_unit": meta.get("K_unit", "DN s^-1 per (W m^-2 sr^-1)"),
        "K": {c: _num(K[i]) for i, c in enumerate(CH)},
        "channel_status": meta.get("channel_status", {}),
        "absolute": True,
        "basis": "photon",
        "camera": str(prov.get("camera", "acA2040-55uc")),
        "lambda_nm": lam.tolist(),
        "psi": {c: psi[i].tolist() for i, c in enumerate(CH)},
        "T_grid": Tg.tolist(),
        "G_tab": {c: G[i].tolist() for i, c in enumerate(CH)},
        "ir_cut_nm": meta.get("ir_cut_nm"),
        "t_sphere_s": meta.get("t_sphere_s"),
        "warnings": meta.get("warnings", []),
    }
    if "tau_bar" in d.files:
        out["tau_bar"] = {c: _num(v) for c, v in zip(CH, np.asarray(d["tau_bar"], float).ravel())}
    return out


def main(argv: list[str]) -> int:
    if not argv or argv[0] in ("-h", "--help"):
        print(__doc__)
        return 0
    src = Path(argv[0])
    dst = Path(argv[1]) if len(argv) > 1 else src.with_suffix(".json")
    dst.write_text(json.dumps(convert(src), indent=1) + "\n")
    print(f"{dst}  K (DN16) = {', '.join(f'{c} {v:.4g}' for c, v in zip(CH, np.load(src)['K'].ravel()))}")
    return 0


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
