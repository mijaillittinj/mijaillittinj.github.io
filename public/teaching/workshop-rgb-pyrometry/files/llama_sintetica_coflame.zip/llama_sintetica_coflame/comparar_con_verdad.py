#!/usr/bin/env python
"""Compara el CSV de la herramienta con verdad_T_fs.csv de la llama sintética (necesita solo numpy).

Mismo cálculo que la página de datos. La verdad se interpola en forma lineal en z y r sobre la malla de
la herramienta, repitiendo en r = 0 el valor de la primera columna. Error de T, raíz del promedio de
(T − T verdadera)² en los píxeles con el bit 1 de mask_bits. Error de f_s, raíz del promedio de
(f_s / f_s verdadera − 1)², en %, en esos píxeles donde la f_s verdadera pasa el 5 % de su máximo.

Uso   python comparar_con_verdad.py resultados_punto_<fecha>.csv [verdad_T_fs.csv]
Acepta el CSV con punto decimal (comas entre columnas) y el CSV en español (punto y coma y coma decimal).
Las líneas que empiezan con # son comentarios y se saltan.

Compares the tool CSV with verdad_T_fs.csv of the synthetic flame, the same metric as the data page.
"""
import sys
from pathlib import Path

import numpy as np


def read_tool(p):
    lines = [l for l in Path(p).read_text(encoding="utf-8").splitlines() if l.strip() and not l.startswith("#")]
    sep = ";" if ";" in lines[0] else ","
    head = lines[0].split(sep)
    num = lambda x: float(x.replace(",", ".")) if x.strip() else np.nan
    a = np.array([[num(x) for x in l.split(sep)] for l in lines[1:]])
    return {h: a[:, i] for i, h in enumerate(head)}


def interp2(zg, rg, V, z, r):
    """Bilinear interpolation on a regular grid, extrapolated by the edge cells."""
    iz = np.clip(np.searchsorted(zg, z) - 1, 0, len(zg) - 2)
    ir = np.clip(np.searchsorted(rg, r) - 1, 0, len(rg) - 2)
    tz = (z - zg[iz]) / (zg[iz + 1] - zg[iz])
    tr = (r - rg[ir]) / (rg[ir + 1] - rg[ir])
    return ((1 - tz) * (1 - tr) * V[iz, ir] + tz * (1 - tr) * V[iz + 1, ir]
            + (1 - tz) * tr * V[iz, ir + 1] + tz * tr * V[iz + 1, ir + 1])


def main():
    if len(sys.argv) < 2:
        print(__doc__)
        return 1
    tool = read_tool(sys.argv[1])
    vp = Path(sys.argv[2]) if len(sys.argv) > 2 else Path(__file__).with_name("verdad_T_fs.csv")
    t = np.loadtxt(vp, delimiter=",", skiprows=1)
    zg, rg = np.unique(t[:, 0]), np.unique(t[:, 1])
    T = t[:, 2].reshape(len(zg), len(rg))
    F = t[:, 3].reshape(len(zg), len(rg))
    rp = np.concatenate([[0.0], rg])
    Tp, Fp = np.concatenate([T[:, :1], T], 1), np.concatenate([F[:, :1], F], 1)
    z, r = tool["z_mm"], tool["r_mm"]
    Tt = interp2(zg, rp, Tp, z, r)
    Ft = np.clip(interp2(zg, rp, Fp, z, r), 0, None)
    used = (tool["mask_bits"].astype(int) & 1) == 1
    dT = tool["T_K"] - Tt
    print(f"píxeles usados {int(used.sum())}")
    print(f"T    error rms {np.sqrt(np.nanmean(dT[used] ** 2)):.1f} K, sesgo medio {np.nanmean(dT[used]):+.1f} K")
    fcol = [h for h in tool if h.startswith("fs")]
    if not fcol:
        print("f_s  el CSV no trae f_s (sin calibración)")
        return 0
    fs = tool[fcol[0]]
    if not fcol[0].startswith("fs_ppm"):
        print(f"f_s  la columna {fcol[0]} no está en ppm, solo se compara T")
        return 0
    mf = used & (Ft > 0.05 * np.nanmax(Ft)) & np.isfinite(fs)
    dF = (fs / Ft - 1) * 100
    print(f"f_s  error rms {np.sqrt(np.nanmean(dF[mf] ** 2)):.1f} % en {int(mf.sum())} píxeles")
    return 0


if __name__ == "__main__":
    sys.exit(main())
